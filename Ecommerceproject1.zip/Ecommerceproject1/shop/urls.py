from django.conf import settings
from django.conf.urls.static import static
from django.urls import path

from . import views

app_name = 'shop'

urlpatterns = [
    path('', views.allProdCaT, name='allProdCaT'),
    path('logout/', views.logout, name='logout'),
    path('<slug:c_slug>/', views.allProdCaT, name='products_by_category'),
    path('<slug:c_slug>/<slug:product_slug>/', views.ProDetail, name='prodCatDetails'),
]

# Add the following line if you are using DEBUG mode to serve static files during development.
# Remove or replace this line in a production environment.
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
