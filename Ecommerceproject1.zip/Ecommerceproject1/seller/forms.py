# seller/forms.py
from django import forms
from .models import Product, Category


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'slug', 'description', 'price', 'category', 'image', 'stock', 'available']

    # Explicitly define the category field as a ModelChoiceField
    category = forms.ModelChoiceField(queryset=None)

    def __init__(self, *args, **kwargs):
        super(ProductForm, self).__init__(*args, **kwargs)

        # Set the queryset for the category field
        self.fields['category'].queryset = Category.objects.all()
class ProductForm1(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'slug','description', 'price',  'image', 'stock', 'available']
