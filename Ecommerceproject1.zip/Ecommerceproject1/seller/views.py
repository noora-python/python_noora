from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import logout as auth_logout
from pyexpat.errors import messages

from seller.forms import ProductForm, ProductForm1
from shop.models import Category, Product
from django.urls import reverse

from django.core.paginator import Paginator,EmptyPage,InvalidPage

# Create your views here.
def index(request):
    return HttpResponse("hai am there")

def allProdCaT(request, c_slug=None):
    c_page = None
    products_list = None

    if c_slug is not None:
        c_page = get_object_or_404(Category, slug=c_slug)
        products_list = Product.objects.filter(category=c_page, available=True)
    else:
        products_list = Product.objects.filter(available=True)
    paginator=Paginator(products_list,2)
    try:
        page=int(request.GET.get('page','1'))
    except:
        page=1
    try:
        products=paginator.page(page)
    except (EmptyPage,InvalidPage):
        products=Paginator.page(Paginator.num_pages)

    return render(request, "category1.html", {'category': c_page, 'products': products})
def ProDetail(request,c_slug,product_slug):
    try:
        product=Product.objects.get(category__slug=c_slug,slug=product_slug)
    except Exception as e:
        raise e
    return render(request,"product1.html",{'product':product})


def logout(request):
    auth_logout(request)
    return redirect('accounts:index')
def detail(request, id):
    product = get_object_or_404(Product, id=id)
    #print(product)
    return render(request, 'details.html', {'product': product})


def add_product(request):
    try:
        categories = Category.objects.all()

        if request.method == 'POST':
            #print(request.POST)
            form = ProductForm(request.POST, request.FILES)
            print(form.errors)
            if form.is_valid():
                # Extract the category ID from the form cleaned data
                category_id = form.cleaned_data['category']

                # Retrieve the category object
                category = get_object_or_404(Category, id=category_id)

                # Assign the category to the form instance before saving
                form.instance.category = category

                form.save()
                messages.success(request, 'Product added successfully.')
                return redirect('seller:allProdCaT')
        else:
            form = ProductForm()

        return render(request, 'add.html', {'form': form, 'categories': categories})
    except Exception as e:
        print(e)
        return HttpResponse("An error occurred. Please try again later.")
def update(request, id):
    product = get_object_or_404(Product, id=id)
    form = ProductForm1(request.POST or None, request.FILES or None, instance=product)

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('seller:detail', id=product.id)

    return render(request, 'edit.html', {'product': product, 'form': form})

def delete(request, id):
    if request.method == 'POST':
        product = get_object_or_404(Product, id=id)
        product.delete()
        # Assuming 'seller:detail' is the correct URL pattern for your 'detail' view
        return redirect('seller:allProdCaT')  # Redirect to the employee page for employees

    return render(request, 'delete.html')
def logout(request):
    auth_logout(request)
    return redirect('accounts:index')