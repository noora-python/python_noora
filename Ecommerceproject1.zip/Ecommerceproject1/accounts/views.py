from django.contrib.auth import login, authenticate
from django.shortcuts import render, redirect
from .forms import SignUpForm, LoginForm  # Assuming your forms are correctly defined in the forms.py file


def index(request):
    return render(request, 'index.html')


def register(request):
    msg = None
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            msg = 'User created'
            return redirect('accounts:login_view')  # Redirect to the login view after successful registration
        else:
            msg = 'Form is not valid'
    else:
        form = SignUpForm()
    return render(request, 'register.html', {'form': form, 'msg': msg})


def login_view(request):
    #print('haiiiiiii')
    form = LoginForm(request.POST or None)
    msg = None

    if request.method == 'POST':
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)

                if hasattr(user, 'is_customer') and user.is_customer:
                    return redirect('shop:allProdCaT')  # Redirect to the customer page for customers
                elif hasattr(user, 'is_employee') and user.is_employee:
                    return redirect('seller:allProdCaT')  # Redirect to the employee page for employees
                else:
                    msg = 'Invalid user role'
            else:
                msg = 'Invalid credentials'
        else:
            msg = 'Form is not valid'
            print(form.errors)  # Print form errors to the console for debugging purposes

    return render(request, 'login.html', {'form': form, 'msg': msg})


def customer(request):
    return render(request, 'customer.html')  # Assuming 'customer.html' is the template for customers


def employee(request):
    return render(request, 'employee.html')  # Assuming 'employee.html' is the template for employees
