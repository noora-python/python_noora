

from django.conf import settings
from django.conf.urls.static import static
from django.urls import path

from .import  views
app_name='accounts'

#from django.contrib import admin
# for name space


urlpatterns = [
    #path('choose/', views.choose_user_type, name='choose_user_type'),
    path('index/',views.index, name='index'),
    path('login/', views.login_view, name='login_view'),
    path('register/', views.register, name='register'),
    #path('adminpage/', views.admin, name='adminpage'),
    path('customer/', views.customer, name='customer'),
    path('employee/', views.employee, name='employee'),




    #path('contact/',views.contact,name='contact')
]

